function i = labindex()
i = 1 ;
