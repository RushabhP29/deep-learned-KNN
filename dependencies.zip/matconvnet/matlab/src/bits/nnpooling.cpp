#ifdef ENABLE_GPU
#error "The file nnpooling.cu should be compiled instead"
#endif
#include "nnpooling.cu"
